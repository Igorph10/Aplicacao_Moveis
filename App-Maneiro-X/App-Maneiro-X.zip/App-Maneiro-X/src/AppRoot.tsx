import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
} from "react-native";

// INTERFACE: Define a estrutura de um objeto, nesse caso, o que é necessário para um usuário de login
// Definindo o que um usuário de login precisa ter
interface UserLogin {
  email: string;
  pass: string;
}

// COMPONENTE PRINCIPAL DO APP
export function AppRoot() {
  // ESTADO TIPADO COM A NOSSA INTERFACE
  const [form, setForm] = useState<UserLogin>({ email: '', pass: '' });

  return (
    // "KeyboardAvoidingView" EVITA QUE O TECLADO CUBRA OS INPUTS NO CELULAR
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}
    >
      <View style={styles.content}>
        {/* Imagem de Login */}
        <Image
          source={{
            uri: "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
          }}
          style={styles.logo}
        />

        <Text style={styles.title}>Olá, Seja Bem-vindo!</Text>    // Texto de boas-vindas

        {/* Caixa de Texto do Login */}
        <TextInput
          style={styles.input}
          placeholder="Digite seu e-mail"
          placeholderTextColor="#999"
          keyboardType="email-address"
          onChangeText={(value) => setForm({ ...form, email: value })}
        />

        <TextInput
          style={styles.input}
          placeholder="Digite sua senha"
          placeholderTextColor="#999"
          secureTextEntry={true} // Esconde a senha
          onChangeText={(value) => setForm({ ...form, pass: value })}
        />

        {/* Botão de Acesso */}
        <TouchableOpacity
          style={styles.button}
          onPress={() => alert('Login Efetuado!')}   // Exibe um alerta com o email digitado
        >
          <Text style={styles.buttonText}>Acessar Sistema</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.link}>
          <Text style={styles.linkText}>Esqueceu a senha?</Text>
        </TouchableOpacity>

        {/* Botão de Cadastro */}
        <TouchableOpacity style={styles.link}>
          <Text style={styles.linkText}>Não tem uma conta? Cadastre-se</Text>
        </TouchableOpacity>

      </View>
    </KeyboardAvoidingView>
  );
}

// ESTILIZAÇÃO - REACT NATIVE
const styles = StyleSheet.create({
  container: {
    flex: 1, // Ocupa a tela toda
    backgroundColor: "#FFF",
  },

  content: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },

  logo: {
    width: 120,
    height: 120,
    marginBottom: 20,
  },

  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 20,
  },

  input: {
    width: "100%",
    height: 50,
    backgroundColor: "#F2F2F2",
    borderRadius: 8,
    paddingHorizontal: 15,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: "#DDD",
  },

  button: {
    width: "100%",
    height: 50,
    backgroundColor: "#66009d",
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 10,
  },

  buttonText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "bold",
  },

  link: {
    marginTop: 20,
  },

  linkText: {
    color: "#66009d",
    fontSize: 14,
    fontWeight: "bold",
  },
});
